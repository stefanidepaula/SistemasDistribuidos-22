const axios = require('axios')

class FilmeController {
    async buscarFilmes(request, response) {

        let array = []

        let res = await axios.get('https://sujeitoprogramador.com/r-api/?api=filmes/')
        
        res.data.forEach((resposta) => {
            array.push({
                "filme": {
                    "foto": resposta.foto,
                    "nome": resposta.nome,
                    "sinopse": resposta.sinopse              
                }
            })
        })

        response.status(200).json(array)
    }
}

module.exports = new FilmeController()
