const { Router } = require('express')
const { buscarFilmes } = require('../src/app/controller/filmeController')

const router = Router()

router.get('/filme', buscarFilmes)

module.exports = router